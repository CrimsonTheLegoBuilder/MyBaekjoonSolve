OVERVIEW
--------

This archive contains all input and output files for the 2nd Day
of Summer Camp 2009.



STATUS OF FILES
---------------

All files included in this archive were created by the members of
Japanese Alumni Group.



TERMS OF USE
------------

You may use all files in this archive, in any form, entirely or in
part, with or without modification, for any purposes, without prior
or posterior consent to Japanese Alumni Group, provided that your
use is made solely at your own risk.

THIS ARCHIVE IS PROVIDED "AS-IS", WITHOUT ANY EXPRESS OR IMPLIED
WARRANTY.  IN NO EVENT SHALL JAPANESE ALUMNI GROUP, THE MEMBERS
OF THE GROUP, OR THE CONTRIBUTORS TO THE GROUP BE LIABLE FOR ANY
DAMAGE ARISING IN ANY WAY OUT OF THE USE OF THE PROBLEM SET, EVEN
IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
